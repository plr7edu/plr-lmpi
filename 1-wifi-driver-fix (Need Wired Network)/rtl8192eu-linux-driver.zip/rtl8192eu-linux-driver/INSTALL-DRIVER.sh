#!/bin/bash
##################################################################################################################
# Author    : plr
##################################################################################################################
#tput setaf 0 = black
#tput setaf 1 = red
#tput setaf 2 = green
#tput setaf 3 = yellow
#tput setaf 4 = dark blue
#tput setaf 5 = purple
#tput setaf 6 = cyan
#tput setaf 7 = gray
#tput setaf 8 = light blue
##################################################################################################################

tput setaf 3;
echo ""
echo "################################################################"
echo "Install Need Packages"
echo "################################################################"
echo ""
echo;tput sgr0

sudo apt-get install git linux-headers-generic build-essential dkms -y
echo ""

tput setaf 3;
echo ""
echo "################################################################"
echo "Add the driver to DKMS"
echo "################################################################"
echo ""
echo;tput sgr0

sudo dkms add .
echo ""

tput setaf 3;
echo ""
echo "################################################################"
echo "Build and install the driver"
echo "################################################################"
echo ""
echo;tput sgr0

sudo dkms install rtl8192eu/1.0
echo ""

tput setaf 3;
echo ""
echo "################################################################"
echo "Build and install the driver"
echo "################################################################"
echo ""
echo;tput sgr0

sudo dkms install rtl8192eu/1.0
echo ""

tput setaf 3;
echo ""
echo "################################################################"
echo "Backlist default RTL8XXXU Driver"
echo "################################################################"
echo ""
echo;tput sgr0

echo "blacklist rtl8xxxu" | sudo tee /etc/modprobe.d/rtl8xxxu.conf
echo ""

tput setaf 3;
echo ""
echo "################################################################"
echo "Force RTL8192EU Driver to be active from boot"
echo "################################################################"
echo ""
echo;tput sgr0

echo -e "8192eu\n\nloop" | sudo tee /etc/modules
echo ""

tput setaf 3;
echo ""
echo "################################################################"
echo "Fix Plugging / Replugging Issue"
echo "################################################################"
echo ""
echo;tput sgr0

echo "options 8192eu rtw_power_mgnt=0 rtw_enusbss=0" | sudo tee /etc/modprobe.d/8192eu.conf
echo ""

tput setaf 3;
echo ""
echo "################################################################"
echo "Update changes to Grub & initramfs"
echo "################################################################"
echo ""
echo;tput sgr0

sudo update-grub; sudo update-initramfs -u
echo ""

tput setaf 2;
echo ""
echo "################################################################"
echo "Please Reboot the System (systemctl reboot -i)"
echo "################################################################"
echo ""
echo;tput sgr0

